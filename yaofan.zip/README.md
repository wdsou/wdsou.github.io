#源分享

网址:www.yfxw.cn  欢迎查找更多的优质程序

# 贫穷网

该源码与Pinqiong.Net “看起来”一致，不过有一些小细节被我去除掉了。使用起来大概也许正常。。

### 配置

密钥对与appid配置

​	'alipay_public_key' => "公钥",

​	'merchant_private_key' => "私钥",

​	'app_id' => "app_id",

数据库配置

​	config.php 内的注释，选中数据库后直接执行即可。

微信通知设置

​	notify.php 里 ftqq.com 那一行

### 捐助

当然 你也可以通过 33.al/donate 捐助我。